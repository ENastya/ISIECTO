package com.example.helper.Pages;

import android.content.Context;
import android.database.DataSetObserver;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.GridLayout;
import android.widget.ListAdapter;
import android.widget.TextView;

import com.example.helper.R;

import java.util.ArrayList;

public class search extends AppCompatActivity {

    GridView items;
    EditText req;
    TextView notFound;
    ArrayList<String> allItems;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.search);
        items = (GridView) findViewById(R.id.gitems);
        items.setVisibility(View.INVISIBLE);
        notFound = (TextView) findViewById(R.id.notfound);
        notFound.setVisibility(View.INVISIBLE);
        allItems = new ArrayList<String>();
        allItems.add("Глобус");
        allItems.add("10p");
        allItems.add("Лента");
        allItems.add("50p");
        allItems.add("Магнит");
        allItems.add("40p");
        makeList();
    }


    public void makeList(){
        items = (GridView) findViewById(R.id.gitems);
        items.setNumColumns(2);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, allItems);
        items.setAdapter(adapter);
    }

    public void search(View v){
        req = (EditText) findViewById(R.id.req);
        String s = "Молоко";
        if (s.equals(req.getText().toString())){
            items.setVisibility(View.VISIBLE);
            notFound.setVisibility(View.INVISIBLE);
        }
        else {
            notFound.setVisibility(View.VISIBLE);
            items.setVisibility(View.INVISIBLE);
        }

    }
}
