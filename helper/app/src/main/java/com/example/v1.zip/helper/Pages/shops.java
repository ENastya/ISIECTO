package com.example.helper.Pages;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.example.helper.R;

public class shops extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.shops);
    }
}
