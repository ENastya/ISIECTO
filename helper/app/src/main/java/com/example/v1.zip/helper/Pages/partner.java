package com.example.helper.Pages;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.helper.R;

public class partner extends AppCompatActivity {

    String logmail = "ana@mail.ru";
    String password = "123";
    Boolean b = false;
    TextView done;
    TextView notdone;
    TextView mail;
    TextView pass;
    EditText email;
    EditText epass;
    Button login;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.partner);
        done  = (TextView) findViewById(R.id.done);
        notdone  = (TextView) findViewById(R.id.notdone);
        mail  = (TextView) findViewById(R.id.mail);
        email  = (EditText) findViewById(R.id.email);
        pass  = (TextView) findViewById(R.id.pass);
        epass  = (EditText) findViewById(R.id.epass);
        login = (Button) findViewById(R.id.login);
        if (!b) {
            done.setVisibility(View.INVISIBLE);
            notdone.setVisibility(View.INVISIBLE);
            login.setVisibility(View.VISIBLE);
            notdone.setVisibility(View.VISIBLE);
            pass.setVisibility(View.VISIBLE);
            epass.setVisibility(View.VISIBLE);
            email.setVisibility(View.VISIBLE);
            mail.setVisibility(View.VISIBLE);
        }
        else {
            done.setVisibility(View.VISIBLE);
            login.setVisibility(View.INVISIBLE);
            notdone.setVisibility(View.INVISIBLE);
            pass.setVisibility(View.INVISIBLE);
            epass.setVisibility(View.INVISIBLE);
            email.setVisibility(View.INVISIBLE);
            mail.setVisibility(View.INVISIBLE);
        }
    }
    public void login (View v) {
        if (epass.getText().toString().equals(password) & email.getText().toString().equals(logmail)){
            done.setVisibility(View.VISIBLE);
            login.setVisibility(View.INVISIBLE);
            notdone.setVisibility(View.INVISIBLE);
            pass.setVisibility(View.INVISIBLE);
            epass.setVisibility(View.INVISIBLE);
            email.setVisibility(View.INVISIBLE);
            mail.setVisibility(View.INVISIBLE);
        }
        else
        {
            done.setVisibility(View.INVISIBLE);
            login.setVisibility(View.VISIBLE);
            notdone.setVisibility(View.VISIBLE);
            pass.setVisibility(View.VISIBLE);
            epass.setVisibility(View.VISIBLE);
            email.setVisibility(View.VISIBLE);
            mail.setVisibility(View.VISIBLE);
        }
    }
}
