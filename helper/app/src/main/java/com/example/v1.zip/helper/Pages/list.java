package com.example.helper.Pages;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.SparseBooleanArray;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.EditText;
import android.widget.TextView;

import com.example.helper.R;

import java.util.ArrayList;

public class list extends AppCompatActivity {
    ListView items;
    EditText item;
    ArrayList <String> allItems;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.list);
        allItems = new ArrayList<String>();
        makeList();
    }

    public void makeList(){
        items = (ListView) findViewById(R.id.items);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_multiple_choice, allItems);
        items.setAdapter(adapter);
    }

    public void addNewItem (View view) {
        item = (EditText) findViewById(R.id.item);
        String text = item.getText().toString();
        allItems.add(text);
        item.setText("");
        makeList();
    }

    public void clearAll(View v){
        allItems = new ArrayList<String>();
        makeList();
    }
}
